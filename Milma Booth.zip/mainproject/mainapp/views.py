from django.shortcuts import render,redirect
from django.views.generic import TemplateView
from django.contrib.auth import login
from django.contrib.auth.models import auth ,User
from mainapp.models import UserType, add_product, feedbk, users

# Create your views here.

class IndexView(TemplateView):
    template_name="index.html"


class login_view(TemplateView):
    template_name="login.html"
    def post(self,request,*args,**kwargs):
        username=request.POST['username']
        print(username)
        password =request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if user is not  None:
            login(request,user)
            if user.last_name=='1':
                if user.is_superuser:
                    return redirect('/admin')
                elif UserType.objects.get(user_id=user.id).type=="office":
                    return redirect('/office')
                elif UserType.objects.get(user_id=user.id).type == "user":
                    return redirect('/user')
                elif UserType.objects.get(user_id=user.id).type=="customer":
                    return redirect('/customer')
                else:
                    return render(request,'login.html',{'message':" User Account Not Authenticated"})
            else:
                return render(request,'login.html',{'message':" User Account Not Authenticated"})
        else:
            return render(request,'index.html',{'message':" Invalid Username or Password"})

class custom_reg(TemplateView):
    template_name="user_reg.html"
    def post(self,request,*arg,**kwargs):
        first_name=request.POST['first_name']
        print(first_name)
        mobile=request.POST['mobile']
        print(mobile)
        email=request.POST['email']
        print(email)
        gender=request.POST['gender']
        print(gender)
        DateOfBirth=request.POST['DateOfBirth']
        print(DateOfBirth)
        pincode=request.POST['pincode']
        print(pincode)
        address=request.POST['address']
        print(address)
        username=request.POST['username']
        print(username)
        password=request.POST['password']
        print(password)
        try:
            user = User.objects.create_user(first_name=first_name,email=email,password=password,username=username,last_name='1')
            table_user=users()
            table_user.user =user
            table_user.mobile =mobile
            table_user.DateOfBirth =DateOfBirth
            table_user.gender =gender
            table_user.address = address
            table_user.pincode=pincode
            table_user.save()
            usertype = UserType()
            usertype.user = user
            usertype.type ='user'
            usertype.save()
            return render(request,'index.html',{'messages':" successfully registered"})
        except:
            messages = "Enter Another Username, user already exist"
            return render(request,'index.html',{'message':messages})
        

class view_product(TemplateView):
   template_name = "view_products.html"
   def get_context_data(self,**kwargs):
        context = super(view_product,self).get_context_data(**kwargs)
        # staff = add_staff.objects.get(user_id=self.request.user.id)
        see = add_product.objects.all()
        context['product'] = see
        return context  

class pass_forgot(TemplateView):
   template_name = "forgot_pass.html" 

class aboutus(TemplateView):
    template_name ="about.html"   

class about_us(TemplateView):
    template_name = "aboutus.html"

   
      
