from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from mainapp.user_views import userhome_page, feedbck, view_product, Singleproducts, addcart, viewcart, RejectcartView, addresses, paying, order_view, pay

urlpatterns = [
   path('',userhome_page.as_view()),
   path('feed_back',feedbck.as_view()),
   path('view_Products',view_product.as_view()),
   path('sproducts',Singleproducts.as_view()),
   path('carts',addcart.as_view()),
   path('viewcarts',viewcart.as_view()),
   path('delcart',RejectcartView.as_view()),
   path('addresss',addresses.as_view()),
   path('paymentss',paying.as_view()),
   path('payi',pay.as_view()),
   path('see_orders',order_view.as_view())

]
def urls():
    return urlpatterns,'user','user'