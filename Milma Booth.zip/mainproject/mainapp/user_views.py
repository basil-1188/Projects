from django.views.generic.base import View
from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from django.contrib.auth.models import User
from mainapp.models import feedbk, add_product, Cart, add_product, users


class userhome_page(TemplateView):
    template_name="user/index.html"


class feedbck(TemplateView):
    template_name="user/add_feed.html"
    def post(self, request, *arg, **kwargs):
        mail = request.POST['mail']
        feedbacks = request.POST['feedbacks']
        subject = request.POST['subject']
        try:
            feed = feedbk()
            feed.user = User.objects.get(id=self.request.user.id)
            feed.mail = mail
            feed.feedbacks = feedbacks  
            feed.subject = subject  

            feed.save()
            return render(request, 'user/index.html', {'message':" Your feedback has been successfully noted"})
        except:
            messages = "ttttt"
            return render(request,'user/index.html',{'message':messages})


class view_product(TemplateView):
   template_name = "user/view_products.html"
   def get_context_data(self,**kwargs):
        context = super(view_product,self).get_context_data(**kwargs)
        # staff = add_staff.objects.get(user_id=self.request.user.id)
        see = add_product.objects.all()
        context['product'] = see
        return context 

class Singleproducts(TemplateView):
    template_name = 'user/singleproduct.html'

    def get_context_data(self, **kwargs):
        id =self.request.GET['id']
        context = super(Singleproducts, self).get_context_data(**kwargs)
        single_view = add_product.objects.get(id=id)

        context['single_view'] = single_view
        return context         
   
class addcart(TemplateView):
    template_name = 'user/singleproduct.html'
    def dispatch(self, request, *args, **kwargs):
        pid = request.POST['id']
        qunty =request.POST['quantity']
        shop = add_product.objects.get(pk=pid)
        price=shop.price
        # qty=shop.quantity
        
        Total= int(qunty)*int(price)
        # shop.quantity=int(qty)-int(qunty)  
        a=int(shop.stock)-int(qunty)
        if a < 0:
            return render(request,'user/index.html',{'message':" Out Of Stock"})
        else:
            shop.stock=a
            shop.save()
            # shopp = shop_reg.objects.get(id=shop.shop_id)
            ca = Cart()
            ca.user = User.objects.get(id=self.request.user.id)
            ca.product = add_product.objects.get(pk=pid)
            ca.payment = 'null'
            ca.quantity=qunty
            ca.status = 'cart'
            ca.delivery = 'null'
            ca.total=Total
            ca.save()
            return redirect(request.META['HTTP_REFERER'],{'message':" cart"})   
        
class viewcart(TemplateView):
    template_name = 'user/cart.html'
    def get_context_data(self, **kwargs):
        context = super(viewcart, self).get_context_data(**kwargs)
        # user = User.objects.get(id=self.request.user.id)
        # id =self.request.GET['id']

        ui = self.request.user.id

        ct = Cart.objects.filter(status='cart', user_id=ui, delivery='null')

        price = 0
        for i in ct:
            price = price + int(i.total)

        context['ct'] = ct
        context['asz'] = price

        return context        
    
class RejectcartView(TemplateView):
    def dispatch(self,request,*args,**kwargs):
        id = request.GET['id']
        Cart.objects.get(id=id).delete()
        return redirect(request.META['HTTP_REFERER'], {'message':" Product Removed"})    

class addresses(TemplateView):
    template_name="user/address.html"        
    def get_context_data(self, **kwargs):
        context = super(addresses, self).get_context_data(**kwargs)
        # p = users.objects.get(user_id=self.request.user.id)
        cr = self.request.user.id
        ct = Cart.objects.filter(status='cart', user_id=cr, delivery='null')
        pi = users.objects.filter(user_id=cr)
        total = 0
        for i in ct:
            total = total + int(i.total)

        context['ct'] = ct
        context['p'] = pi
        context['asz'] = total

        return context
       
    # def get_context_another_data(self, **kwargs):
    #     context = super(addresses, self).get_context_data(**kwargs)
    #     p = users.objects.get(user_id=self.request.user.id)
    #     context['p'] = p
    #     return context


class paying(TemplateView):
    template_name="user/payments.html"
    def get_context_data(self, **kwargs):
        context = super(paying, self).get_context_data(**kwargs)
        # user = User.objects.get(id=self.request.user.id)
        # id =self.request.GET['id']

        cr = self.request.user.id

        ct = Cart.objects.filter(status='cart', user_id=cr, delivery='null')

        total = 0
        for i in ct:
            total = total + int(i.total)

        context['ct'] = ct
        context['asz'] = total

        return context

class pay(TemplateView):
    template_name="user/payment.html"
    def dispatch(self,request,*args,**kwargs):
        pid = self.request.user.id
        ch = Cart.objects.filter(user_id=pid,status='cart')
        print(ch)
        for i in ch:
            i.payment='paid'
            i.status='Order Placed'
            i.save()
        return render(request,'user/index.html', {'message':" payment Successfull, Check Booking Details"})   
        
class order_view(TemplateView):
    template_name = 'user/view_orders.html'
    def get_context_data(self, **kwargs):
        context = super(order_view,self).get_context_data(**kwargs)
        id=self.request.user.id
        cart = Cart.objects.filter(payment='paid',user_id=id)

        context['cart'] = cart
        return context    









       
