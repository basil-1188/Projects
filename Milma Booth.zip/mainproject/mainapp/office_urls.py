from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings
from mainapp.office_views import office_page, customs, view_feed, measure_page, user_reg, stock_status, sales_view, orderapprove, rejectproduct

urlpatterns = [
   path('',office_page.as_view()),
   path('measure',measure_page.as_view()),
   path('customerss',customs.as_view()),
   path('feedsbb',view_feed.as_view()),
   path('customss',user_reg.as_view()),
   path('view_stockstatus',stock_status.as_view()),
   path('all_sales',sales_view.as_view()),
   path('approveorder',orderapprove.as_view()),
   path('orderreject',rejectproduct.as_view())



]
def urls():
    return urlpatterns,'office','office'