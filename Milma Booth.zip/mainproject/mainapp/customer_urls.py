from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from mainapp.customer_views import Uhome_page, feedbck, viewreadings, cashdetails, datesearch

urlpatterns = [
   path('',Uhome_page.as_view()),
   path('feedbacks',feedbck.as_view()),
   path('reading',viewreadings.as_view()),
   path('view_cashdetail',cashdetails.as_view()),
   path('datefilter',datesearch.as_view())

   


]
def urls():
    return urlpatterns,'customer','customer'