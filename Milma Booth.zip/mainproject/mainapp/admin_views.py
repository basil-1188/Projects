from django.views.generic.base import View
from django.shortcuts import render
from django.views.generic import TemplateView
from django.contrib.auth.models import User
from mainapp.models import UserType, staff_reg, add_product, office_register, add_product, users, user_register, Cart
from django.core.files.storage import FileSystemStorage
from mainapp.views import view_product


class Admin_IndexView(TemplateView):
    template_name = "admin/index.html"

class add_staff(TemplateView):
    template_name="admin/add_staff.html"
    def post(self,request,*arg,**kwargs):
        first_name=request.POST['first_name']
        print(first_name)
        mobile=request.POST['mobile']
        print(mobile)
        email=request.POST['email']
        print(email)
        gender=request.POST['gender']
        print(gender)
        address=request.POST['address']
        print(address)
        username=request.POST['username']
        print(username)
        password=request.POST['password']
        print(password)
        try:
            user = User.objects.create_user(first_name=first_name,email=email,password=password,username=username,last_name='1')
            table_user=staff_reg()
            table_user.user =user
            table_user.mobile =mobile
            table_user.gender =gender
            table_user.address = address
            table_user.save()
            usertype = UserType()
            usertype.user = user
            usertype.type ='staff'
            usertype.save()
            return render(request,'admin/index.html',{'messages':" successfully registered"})
        except:
            messages = "Enter Another Username, user already exist"
            return render(request,'admin/index.html',{'message':messages})    
        
class Add_product(TemplateView):
    template_name = "admin/add_product.html"

    def post(self, request, *arg, **kwargs):
        user = User.objects.get(pk=self.request.user.id)
        name = request.POST['name']
        price = request.POST['price']
        quantity = request.POST['quantity']
        description = request.POST['description']
        stock = request.POST['stock']
        image = request.FILES['image']
        fii = FileSystemStorage()
        files = fii.save(image.name, image) 

        product = add_product()
        product.user = user
        product.name = name
        product.price = price
        product.quantity = quantity
        product.description = description
        product.stock = stock
        product.image = files
        product.save()

        return render(request, 'admin/index.html', {'message':" product successfully added"})

class view_product(TemplateView):
   template_name = "admin/product_delete.html"
   def get_context_data(self,**kwargs):
        context = super(view_product,self).get_context_data(**kwargs)
        # staff = add_staff.objects.get(user_id=self.request.user.id)
        see = add_product.objects.all()
        context['pro'] = see
        return context          
    
class product_reject(View):
    def dispatch(self,request,*args,**kwargs):
        id = request.GET['id']
        add_product.objects.get(id=id).delete()
        return render(request, 'admin/index.html', {'message':" Product Deleted"})    

class reg_office(TemplateView):
    template_name="admin/office_reg.html"
    def post(self,request,*arg,**kwargs):
        offi_name=request.POST['offi_name']
        print(offi_name)
        mobile=request.POST['mobile']
        print(mobile)
        email=request.POST['email']
        print(email)
        address=request.POST['address']
        print(address)
        username=request.POST['username']
        print(username)
        password=request.POST['password']
        print(password)
        try:
            user = User.objects.create_user(first_name=offi_name,email=email,password=password,username=username,last_name='1')
            table_user=office_register()
            table_user.user =user
            table_user.mobile =mobile
            table_user.address = address
            table_user.save()
            usertype = UserType()
            usertype.user = user
            usertype.type ='office'
            usertype.save()
            return render(request,'admin/index.html',{'messages':" office successfully registered"})
        except:
            messages = "Enter Another Username, user already exist"
            return render(request,'admin/index.html',{'message':messages})    
                       
class products_update(TemplateView):
    template_name = 'admin/update_product.html'
    def get_context_data(self, **kwargs):
        context = super(products_update, self).get_context_data(**kwargs)
        id=self.request.GET['id']
        pro = add_product.objects.get(id=id)
        context['pro'] = pro
        return context
    
    def post(self, request, *args, **kwargs):
        id = request.POST['id'] 
        name = request.POST['name']
        quantity = request.POST['quantity']
        price = request.POST['price']
        description = request.POST['description']
        # image = request.FILES['image']
        # fii =  FileSystemStorage()
        # filess = fii.save(image.name,image)
       
        
        pr = add_product.objects.get(pk=id)
        pr.name = name
        pr.price = price
        pr.quantity = quantity
        pr.description = description
        # pr.image = filess
        pr.save()
        
        return render(request,'admin/index.html',{'message':" Updated"})
    
class view_stock(TemplateView):
    template_name="admin/stock_status.html"
    def get_context_data(self, **kwargs):
        context = super(view_stock,self).get_context_data(**kwargs)
        product_list = add_product.objects.all()
        context['product_list'] = product_list
        return context    

class view_report(TemplateView):
    template_name="admin/report.html"    
    def get_context_data(self, **kwargs):
        context = super(view_report,self).get_context_data(**kwargs)

        pro = add_product.objects.all()
        pro1= office_register.objects.all()
        pro2 = users.objects.all()
        pro3 = user_register.objects.all()
        pro4 = Cart.objects.all()
        pro5= staff_reg.objects.all()

        context['pro4'] = pro4
        context['pro'] = pro
        context['pro1'] = pro1
        context['pro2'] = pro2

        context['pro3'] = pro3
       
       
        context['pro5']= pro5
        return context
