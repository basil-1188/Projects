from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from django.urls import path
from mainapp.admin_views import Admin_IndexView, add_staff, Add_product, view_product, product_reject, reg_office, products_update, view_stock, view_report

urlpatterns = [
   path('',Admin_IndexView.as_view()),
   path('staf_add',add_staff.as_view()),
   path('product_add',Add_product.as_view()),
   path('view_pro',view_product.as_view()),
   path('reject',product_reject.as_view()),
   path('office',reg_office.as_view()),
   path('update',products_update.as_view()),
   path('view_stockstatus',view_stock.as_view()),
   path('reportview',view_report.as_view())







]
def urls():
    return urlpatterns,'admin','admin'