from django.views.generic.base import View
from django.shortcuts import render
from django.views.generic import TemplateView
from django.contrib.auth.models import User
from mainapp.models import feedbk, measure

class Uhome_page(TemplateView):
    template_name="customer/index.html"

class feedbck(TemplateView):
    template_name="customer/add_feed.html"

    def post(self, request, *arg, **kwargs):
        mail = request.POST['mail']
        feedbacks = request.POST['feedbacks']
        subjects = request.POST['subjects']

        try:
            feed = feedbk()
            feed.user = User.objects.get(id=self.request.user.id)
            feed.mail = mail
            feed.feedbacks = feedbacks  
            feed.subject = subjects  

            feed.save()
            return render(request, 'customer/index.html', {'message':" Your feedback has been successfully noted"})
        except:
            messages = "ttttt"
            return render(request,'customer/index.html',{'message':messages})

class viewreadings(TemplateView):
    template_name = 'customer/readings.html'

    def get_context_data(self, **kwargs):
        context = super(viewreadings, self).get_context_data(**kwargs)
        ui = self.request.user.id
        b = measure.objects.filter(user_id=ui)
        context['b'] = b
        return context
class datesearch(View):
    def post(self, request, *args, **kwargs):
        try:
            DateEntry = request.POST['search']
            host = measure.objects.filter(DateEntry=DateEntry)
        except ValueError:
            host = measure.objects.none()
        return render(request, 'customer/readings.html', {'sho': host})
    
# class datesearch(View):
#     def post(self, request, *args, **kwargs):
#         DateEntry = request.POST['search']
#         host = measure.objects.filter(DateEntry__icontains=DateEntry)
#         return render(request, 'customer/readings.html', {'sho':host})

class cashdetails(TemplateView):
    template_name = 'customer/view_cashdetails.html'

    def get_context_data(self, **kwargs):
        context = super(cashdetails, self).get_context_data(**kwargs)
        ui = self.request.user.id
        b = measure.objects.filter(user_id=ui)
        tot=0
        for i in b:
            tot= tot + int(i.totalprice)
    #     for i in b:
    #         i.tot = i.milkprize * i.total
    #         tot += i.tot
        
        context['b'] = b
        context['tot'] = tot
        return context
    