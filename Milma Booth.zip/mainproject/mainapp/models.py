from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class UserType(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    type = models.CharField(max_length=50)

class user_register(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    mobile =models.CharField(max_length=100,null=True)
    DateOfBirth =models.DateField(max_length=100,null=True)
    gender =models.CharField(max_length=100,null=True)
    # image = models.ImageField(upload_to='images/',null=True)
    address =models.CharField(max_length=100,null=True)
    pincode =models.CharField(max_length=100,null=True)

class staff_reg(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    mobile =models.CharField(max_length=100,null=True)
    gender =models.CharField(max_length=100,null=True)
    address =models.CharField(max_length=100,null=True)

class add_product(models.Model):
    name = models.CharField(max_length=50,null=True)
    price =models.CharField(max_length=50,null=True)
    description =models.CharField(max_length=50,null=True)
    image = models.ImageField(upload_to='images/',null=True)
    quantity =models.IntegerField(null=True)
    stock =models.IntegerField(null=True)
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True)

class office_register(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    mobile =models.CharField(max_length=100,null=True)
    address =models.CharField(max_length=100,null=True)

class feedbk(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    mail= models.CharField(max_length=100,null=True)
    feedbacks =models.CharField(max_length=200,null=True)   
    subject =models.CharField(max_length=200,null=True)  
      

class users(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    mobile =models.CharField(max_length=100,null=True)
    DateOfBirth =models.DateField(max_length=100,null=True)
    gender =models.CharField(max_length=100,null=True)
    address =models.CharField(max_length=100,null=True)
    pincode =models.CharField(max_length=100,null=True)   

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    product = models.ForeignKey(add_product, on_delete=models.CASCADE, null=True)
    quantity =models.IntegerField(default=1,null=True)
    total = models.CharField(max_length=100,null=True)
    payment = models.CharField(max_length=100,null=True)
    status = models.CharField(max_length=100,null=True)
    total = models.CharField(max_length=100,null=True)
    delivery = models.CharField(max_length=100,null=True)
    
class measure(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    lactometer =models.CharField(max_length=100,null=True) 
    milkprize =models.CharField(max_length=100,null=True)    
    clot_onboil =models.CharField(max_length=100,null=True)    
    acidity =models.CharField(max_length=100,null=True)    
    gerber_test =models.CharField(max_length=100,null=True)  
    total =models.CharField(max_length=100,null=True)   
    DateEntry =models.CharField(max_length=100,null=True)
    totalprice =models.CharField(max_length=100,null=True)    
