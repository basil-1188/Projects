from django.shortcuts import render, redirect
from django.views.generic import TemplateView, View
from django.contrib.auth.models import auth ,User
from mainapp.models import UserType, user_register, feedbk, add_product, Cart, measure

class office_page(TemplateView):
    template_name="office/index.html"

class user_reg(TemplateView):
    template_name="office/cust_reg.html"
    def post(self,request,*arg,**kwargs):
        first_name=request.POST['first_name']
        print(first_name)
        mobile=request.POST['mobile']
        print(mobile)
        email=request.POST['email']
        print(email)
        gender=request.POST['gender']
        print(gender)
        DateOfBirth=request.POST['DateOfBirth']
        print(DateOfBirth)
        pincode=request.POST['pincode']
        print(pincode)
        address=request.POST['address']
        print(address)
        username=request.POST['username']
        print(username)
        password=request.POST['password']
        print(password)
        try:
            user = User.objects.create_user(first_name=first_name,email=email,password=password,username=username,last_name='1')
            table_user=user_register()
            table_user.user =user
            table_user.mobile =mobile
            table_user.DateOfBirth =DateOfBirth
            table_user.gender =gender
            table_user.address = address
            table_user.pincode=pincode
            table_user.save()
            usertype = UserType()
            usertype.user = user
            usertype.type ='customer'
            usertype.save()
            return render(request,'office/index.html',{'messages':" successfully registered"})
        except:
            messages = "Enter Another Username, user already exist"
            return render(request,'office/index.html',{'message':messages})
      

class customs(TemplateView):
    template_name="office/customers.html"
    def get_context_data(self,**kwargs):
        context = super(customs,self).get_context_data(**kwargs)
        # staff = add_staff.objects.get(user_id=self.request.user.id)
        see = user_register.objects.all()
        context['custom'] = see
        return context     

class view_feed(TemplateView):
   template_name = "office/view_fdbck.html"
   def get_context_data(self,**kwargs):
        context = super(view_feed,self).get_context_data(**kwargs)
        see = feedbk.objects.all()
        context['fee'] = see
        return context
   

class measure_page(TemplateView):
    template_name="office/add_measure.html"  
           
    def post(self, request, *arg, **kwargs):
        id = request.GET['id']  
        user=User.objects.get(id=id)
        total = request.POST['total']
        lact_read = request.POST['lact_read']    
        clot_read = request.POST['clot_read']
        acidi_read = request.POST['acidi_read']
        gerber_read = request.POST['gerber_read']
        dateentry = request.POST['dateentry']
        milkprize  = request.POST['milkprize']
        totalprice= int(total)*int(milkprize)


        meas = measure()
        meas.user_id= user.id
        meas.lactometer = lact_read
        meas.clot_onboil = clot_read
        meas.acidity = acidi_read
        meas.gerber_test = gerber_read
        meas.total = total
        meas.DateEntry = dateentry
        meas.milkprize = milkprize
        meas.totalprice = totalprice
        meas.save()

        return render(request, 'office/index.html', {'message':" measurement successfully added"})

class stock_status(TemplateView):
    template_name="office/view_stock.html"
    def get_context_data(self, **kwargs):
        context = super(stock_status,self).get_context_data(**kwargs)
        product_list = add_product.objects.all()
        context['product_list'] = product_list
        return context
    
class sales_view(TemplateView):
    template_name="office/view_sales.html"    
    def get_context_data(self, **kwargs):
        context = super(sales_view,self).get_context_data(**kwargs)
        id=self.request.user.id
        cart = Cart.objects.filter(payment='paid')

        context['cart'] = cart
        return context   
class rejectproduct(TemplateView):
    def dispatch(self,request,*args,**kwargs):
        id = request.GET['id']
        Cart.objects.get(id=id).delete()
        return redirect(request.META['HTTP_REFERER'], {'message':"Order has been declined"})     

class orderapprove(View):
    def dispatch(self, request, *args, **kwargs):
        id = request.GET['id']
        booking = Cart.objects.get(pk=id)
        booking.status = 'Order Accepted'
        booking.delivery = 'Product despatched'
        booking.save()
        return render(request,'office/index.html',{'message':" Order has been updated"})  