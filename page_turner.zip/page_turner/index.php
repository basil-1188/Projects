<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAGE TURNER</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect"  href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400;1,600;1,700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="banner" style="background-image: linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)),url(images/pexels-pixabay-159711.jpg);
    background-position: center;
    background-size: cover;
">
<div class="navbar">
    <a href="index.html"><img src="images/Sunday Lounge.jpeg" class="logo" alt=""></a>
    <ul>
        <li><a href="login.php">LOGIN</a></li>
        <li><a href="registration.php">REGISTRATION</a></li>
    </ul>
</div>
<div class="content">
    <h1>PAGE TURNER</h1>
    <p>Your Gateway to Endless Reading</p>
    <div class="wrapper">
        <a href="home.html">GET STARTED</a>
      </div>
</div>

    </div>
</body>
</html>