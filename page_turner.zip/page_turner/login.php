<?php
    include("includes/connection.php")
?>
<form action="" method="post">
    <label for="">Username</label>
    <input type="number" name="username" placeholder="Username">
    <label for="">Password</label>
    <input type="text" name="password" placeholder="Password">
    <input type="submit" name="submit">
</form>